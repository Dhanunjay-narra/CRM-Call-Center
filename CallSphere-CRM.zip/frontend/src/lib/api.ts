const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

class ApiClient {
  private token: string | null = null;

  setToken(token: string) {
    this.token = token;
    if (typeof window !== 'undefined') {
      localStorage.setItem('callsphere_token', token);
    }
  }

  getToken(): string | null {
    if (this.token) return this.token;
    if (typeof window !== 'undefined') {
      return localStorage.getItem('callsphere_token');
    }
    return null;
  }

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const token = this.getToken();
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(options.headers as Record<string, string>),
    };

    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const res = await fetch(`${API_BASE}/api/v1${endpoint}`, {
      ...options,
      headers,
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: 'Network request failed' }));
      throw new Error(err.detail || `API error ${res.status}`);
    }

    return res.json();
  }

  // Auth & Identity
  async register(data: any) { return this.request<any>('/auth/register', { method: 'POST', body: JSON.stringify(data) }); }
  async login(data: any) { return this.request<any>('/auth/login', { method: 'POST', body: JSON.stringify(data) }); }
  async getMe() { return this.request<any>('/auth/me'); }
  async listUsers() { return this.request<any[]>('/users'); }

  // CRM
  async listLeads(params?: string) { return this.request<any[]>(`/leads${params ? `?${params}` : ''}`); }
  async createLead(data: any) { return this.request<any>('/leads', { method: 'POST', body: JSON.stringify(data) }); }
  async convertLead(id: string, data: any) { return this.request<any>(`/leads/${id}/convert`, { method: 'POST', body: JSON.stringify(data) }); }
  async listCustomers() { return this.request<any[]>('/customers'); }
  async getCustomer360(id: string) { return this.request<any>(`/customers/${id}/360`); }
  async listContacts() { return this.request<any[]>('/contacts'); }

  // Sales
  async listPipelines() { return this.request<any[]>('/pipelines'); }
  async listOpportunities() { return this.request<any[]>('/opportunities'); }
  async createOpportunity(data: any) { return this.request<any>('/opportunities', { method: 'POST', body: JSON.stringify(data) }); }
  async updateOpportunity(id: string, data: any) { return this.request<any>(`/opportunities/${id}`, { method: 'PATCH', body: JSON.stringify(data) }); }
  async getSalesForecast() { return this.request<any>('/sales/forecast'); }

  // Telephony & Softphone
  async getAgentProfile() { return this.request<any>('/agents/profile'); }
  async setAgentState(state: string, break_type?: string) { return this.request<any>('/agents/state', { method: 'POST', body: JSON.stringify({ state, break_type }) }); }
  async listAllAgents() { return this.request<any[]>('/agents/all'); }
  async initiateCall(data: any) { return this.request<any>('/calls/initiate', { method: 'POST', body: JSON.stringify(data) }); }
  async answerCall(id: string) { return this.request<any>(`/calls/${id}/answer`, { method: 'POST' }); }
  async holdCall(id: string, hold: boolean) { return this.request<any>(`/calls/${id}/hold?hold=${hold}`, { method: 'POST' }); }
  async endCall(id: string) { return this.request<any>(`/calls/${id}/end`, { method: 'POST' }); }
  async submitDisposition(id: string, data: any) { return this.request<any>(`/calls/${id}/disposition`, { method: 'POST', body: JSON.stringify(data) }); }

  // Support & SLA
  async listTickets() { return this.request<any[]>('/tickets'); }
  async createTicket(data: any) { return this.request<any>('/tickets', { method: 'POST', body: JSON.stringify(data) }); }
  async resolveTicket(id: string, data: any) { return this.request<any>(`/tickets/${id}/resolve`, { method: 'POST', body: JSON.stringify(data) }); }

  // Omnichannel & Inbox
  async listConversations() { return this.request<any[]>('/conversations'); }
  async getMessages(convId: string) { return this.request<any[]>(`/conversations/${convId}/messages`); }
  async sendMessage(data: any) { return this.request<any>('/messages/send', { method: 'POST', body: JSON.stringify(data) }); }

  // Analytics & Global Search
  async getOperationalKPIs() { return this.request<any>('/analytics/operational'); }
  async getSalesAnalytics() { return this.request<any>('/analytics/sales'); }
  async getExecutiveSummary() { return this.request<any>('/analytics/executive'); }
  async searchGlobal(q: string) { return this.request<any>(`/search?q=${encodeURIComponent(q)}`); }
}

export const api = new ApiClient();
