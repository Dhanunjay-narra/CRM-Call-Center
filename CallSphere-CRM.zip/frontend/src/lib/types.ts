export type AgentState = 'AVAILABLE' | 'BUSY' | 'ON_CALL' | 'AFTER_CALL_WORK' | 'BREAK' | 'TRAINING' | 'OFFLINE';

export type BreakType = 'LUNCH' | 'TEA' | 'PERSONAL' | 'TRAINING' | 'MEETING' | 'TECHNICAL_ISSUE' | 'OTHER';

export type CallStatus = 'QUEUED' | 'RINGING' | 'IN_PROGRESS' | 'ON_HOLD' | 'AFTER_CALL_WORK' | 'COMPLETED' | 'MISSED' | 'ABANDONED';

export type LeadStatus = 'NEW' | 'CONTACTED' | 'QUALIFIED' | 'NURTURING' | 'OPPORTUNITY' | 'WON' | 'LOST';

export type ChannelType = 'EMAIL' | 'SMS' | 'WHATSAPP' | 'VOICE' | 'IN_APP';

export type TicketStatus = 'NEW' | 'ASSIGNED' | 'IN_PROGRESS' | 'WAITING_CUSTOMER' | 'RESOLVED' | 'CLOSED';

export type TicketPriority = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export interface UserProfile {
  id: string;
  organization_id: string;
  email: string;
  full_name: string;
  role: string;
  timezone: string;
  language: string;
}

export interface Customer {
  id: string;
  name: string;
  email?: string;
  phone_number?: string;
  health_score: number;
  engagement_score: number;
  sentiment: 'POSITIVE' | 'NEUTRAL' | 'NEGATIVE';
  preferred_channel: string;
  lifetime_value: number;
  open_opportunities_count: number;
  open_tickets_count: number;
}

export interface Lead {
  id: string;
  first_name: string;
  last_name?: string;
  email?: string;
  phone_number?: string;
  company_name?: string;
  score: number;
  estimated_value: number;
  status: LeadStatus;
  is_converted: boolean;
}

export interface Opportunity {
  id: string;
  title: string;
  amount: number;
  probability: number;
  status: 'OPEN' | 'WON' | 'LOST';
  stage_id: string;
}

export interface SupportTicket {
  id: string;
  ticket_number: string;
  title: string;
  description: string;
  priority: TicketPriority;
  status: TicketStatus;
  sla_status: string;
  created_at: string;
}

export interface TimelineEvent {
  id: string;
  channel: string;
  event_type: string;
  title: string;
  description?: string;
  actor_name: string;
  occurred_at: string;
  metadata_json: Record<string, any>;
}

export interface OperationalKPIs {
  total_calls_today: number;
  answered_calls: number;
  missed_calls: number;
  abandoned_calls: number;
  answer_rate_percent: number;
  service_level_percent: number;
  aht_seconds: number;
  asa_seconds: number;
  fcr_percent: number;
  occupancy_percent: number;
  active_calls_count: number;
  agents_online: number;
  agents_available: number;
  agents_on_call: number;
  agents_on_break: number;
}
