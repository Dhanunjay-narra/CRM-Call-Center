"""CRM Core Domain package"""
